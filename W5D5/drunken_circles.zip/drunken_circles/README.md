# w6d1: DrunkenCircles Demo

**[Live Demo][live-demo]**

* [index.html][index.html]
* [lib/circle.js][circle.js]
* [lib/game.js][game.js]

[live-demo]: http://appacademy.github.io/DrunkenCircles/
[index.html]: index.html
[circle.js]: lib/circle.js
[game.js]: lib/game.js

## Instructions to Run Locally

0. Navigate to the project directory in your terminal.
0. `$ webpack main.js bundle.js`
0. `$ open index.html`
